* [e4e97ae](https://github.com/TryGhost/Casper/commit/e4e97ae) 2.10.4 - Kevin Ansfield
* [df7c232](https://github.com/TryGhost/Casper/commit/df7c232) Updated links to docs site - Aileen Nowak
